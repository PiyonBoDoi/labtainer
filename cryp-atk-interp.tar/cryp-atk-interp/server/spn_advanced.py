import random

def generate_key():
    # Sinh khóa ngẫu nhiên trong khoảng 0 đến 255
    key = random.randint(0, 255)
    return key

SBOX = [
    0x6, 0x4, 0xC, 0x5,
    0x0, 0x7, 0x2, 0xE,
    0x1, 0xF, 0x3, 0xD,
    0x8, 0xA, 0x9, 0xB
]

INV_SBOX = [SBOX.index(i) for i in range(16)]

PBOX = [0, 2, 4, 6, 1, 3, 5, 7]
INV_PBOX = [PBOX.index(i) for i in range(8)]

def permute(byte):
    result = 0
    for i in range(8):
        bit = (byte >> i) & 1
        result |= bit << PBOX[i]
    return result

def inverse_permute(byte):
    result = 0
    for i in range(8):
        bit = (byte >> i) & 1
        result |= bit << INV_PBOX[i]
    return result

def substitute(byte):
    hi = (byte >> 4) & 0xF
    lo = byte & 0xF
    return (SBOX[hi] << 4) | SBOX[lo]

def inverse_substitute(byte):
    hi = (byte >> 4) & 0xF
    lo = byte & 0xF
    return (INV_SBOX[hi] << 4) | INV_SBOX[lo]

def get_round_key(base_key, round_index, mode):
    if mode == 1:
        return base_key  # luôn dùng cùng một key
    elif mode == 2:
        return (base_key + round_index * 17) % 256  # biến key theo vòng

def encrypt_byte(byte, key, num_rounds=3, key_mode=1):
    state = byte ^ key
    for i in range(num_rounds):
        state = substitute(state)
        state = permute(state)
        round_key = get_round_key(key, i, key_mode)
        state ^= round_key
    return state

def decrypt_byte(byte, key, num_rounds=3, key_mode=1):
    state = byte
    for i in reversed(range(num_rounds)):
        round_key = get_round_key(key, i, key_mode)
        state ^= round_key
        state = inverse_permute(state)
        state = inverse_substitute(state)
    state ^= key
    return state

def encrypt_text(text, key, num_rounds=3, key_mode=1):
    return bytes([encrypt_byte(b, key, num_rounds, key_mode) for b in text])

def decrypt_text(cipher, key, num_rounds=3, key_mode=1):
    return bytes([decrypt_byte(b, key, num_rounds, key_mode) for b in cipher])

def main():
    key = 0xA7

    try:
        num_rounds = int(input("Nhập số vòng mã hóa (ví dụ: 1, 3, 4...): "))
        key_mode = int(input("Chọn chế độ key (1: cố định, 2: biến đổi): "))
        filename = input("Nhập tên file plaintext cần mã hóa: ")
    except ValueError:
        print("Lỗi: Nhập số không hợp lệ.")
        return

    try:
        with open(filename, "rb") as f:
            plaintext = f.read()
    except IOError as e:
        print("Lỗi đọc file:", e)
        return

    print("Plaintext:", plaintext.decode(errors='ignore'))

    ciphertext = encrypt_text(plaintext, key, num_rounds, key_mode)
    with open("cipher.txt", "wb") as f:
        f.write(ciphertext)
    print("Encrypted bytes:", ciphertext)

    decrypted = decrypt_text(ciphertext, key, num_rounds, key_mode)
    with open("decrypted.txt", "wb") as f:
        f.write(decrypted)
    print("Decrypted:", decrypted.decode(errors='ignore'))

    # Ghi thông tin cấu hình vào file setting.txt (thêm vào cuối)
    try:
        with open("setting.txt", "a", encoding="utf-8") as fset:
            fset.write("=== Thông tin cấu hình mã hóa ===\n")
            fset.write(f"Tên file plaintext: {filename}\n")
            fset.write(f"Số vòng mã hóa: {num_rounds}\n")
            fset.write(f"Chế độ key: {key_mode} ({'Cố định' if key_mode == 1 else 'Biến đổi'})\n")
            fset.write(f"Khóa sử dụng: 0x{key:02X}\n")
            fset.write("----------------------------------------\n")
    except IOError as e:
        print("Lỗi ghi file cấu hình:", e)

if __name__ == "__main__":
    main()

