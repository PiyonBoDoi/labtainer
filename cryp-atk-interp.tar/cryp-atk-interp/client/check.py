def hamming_distance(b1, b2):
    # Tinh khoang cach Hamming giua 2 byte sequence
    return sum(bin(x ^ y).count("1") for x, y in zip(b1, b2))

def main():
    file1 = input("Nhap ten file 1 (goc): ")
    file2 = input("Nhap ten file 2 (de so sanh): ")

    try:
        with open(file1, "rb") as f1, open(file2, "rb") as f2:
            data1 = f1.read()
            data2 = f2.read()
    except IOError as e:
        print("Loi mo file:", e)
        return

    min_len = min(len(data1), len(data2))
    if min_len == 0:
        print("Mot trong hai file rong hoac khong hop le.")
        return

    hd = hamming_distance(data1[:min_len], data2[:min_len])
    percent_similarity = 100.0 - (hd / (8 * min_len) * 100)

    print("Muc do tuong dong: %.2f%%" % percent_similarity)

    if percent_similarity >= 85:
        conclusion = "Chap nhan"
    else:
        conclusion = "Thap"

    print("Ket luan:", conclusion)

    # Ghi ket qua vao file result.txt
    try:
        with open("tuongdong.txt", "a", encoding="utf-8") as fout:
            fout.write(f"File 1: {file1}\n")
            fout.write(f"File 2: {file2}\n")
            fout.write(f"Muc do tuong dong: {percent_similarity:.2f}%\n")
            fout.write(f"Ket luan: {conclusion}\n")
            fout.write("-" * 40 + "\n")
    except IOError as e:
        print("Loi ghi file result.txt:", e)

if __name__ == "__main__":
    main()

