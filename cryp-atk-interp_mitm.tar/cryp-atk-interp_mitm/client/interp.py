import galois
from collections import OrderedDict

# Ham doc tep nhi phan (cipher) va chuyen thanh chuoi hex
def read_cipher_as_hex(filename):
    with open(filename, "rb") as f:
        binary_data = f.read()
        return binary_data

# Tao truong huu han GF(2^8) voi da thuc bat kha quy
GF256 = galois.GF(2**8, irreducible_poly=galois.Poly.Int(0x11b))

def main():
    plaintext_filename = input("Nhap ten file plaintext: ")
    cipher_filename = "cipher.txt"  # Giữ nguyên ten file cipher.txt

    # Doc plaintext de xac dinh do dai cac tu
    try:
        with open(plaintext_filename, "r", encoding="utf-8") as f:
            plaintexts = [line.strip() for line in f if line.strip()]
    except IOError as e:
        print("Loi doc file plaintext:", e)
        return

    # Doc cipher va chuyen thanh hex
    try:
        cipher_bytes = read_cipher_as_hex(cipher_filename)
    except IOError as e:
        print("Loi doc file cipher:", e)
        return
    cipher_hex = cipher_bytes.hex()

    # Tach cipher_hex theo do dai moi tu va luu vao cipher_hex.txt
    idx = 0
    with open("cipher_hex.txt", "w", encoding="utf-8") as f_hex:
        print("Cipher hex (moi tu mot dong):")
        for i, plain in enumerate(plaintexts):
            length = len(plain) * 2  # Moi byte = 2 ky tu hex
            word_hex = cipher_hex[idx:idx+length]
            if word_hex:
                f_hex.write(word_hex + '\n')
                print(f"Tu {i+1} (plaintext: {plain}): {word_hex}")
            idx += length

    # Ghep tung tu voi doan hex tuong ung
    pairs = []
    idx = 0
    for plain in plaintexts:
        length = len(plain) * 2
        c_hex = cipher_hex[idx:idx+length]
        pairs.append((plain, c_hex))
        idx += length

    # Ghi ket qua giai ma vao filegiaima.txt va space_points.txt
    with open("filegiaima.txt", "w", encoding="utf-8") as fout, \
         open("space_points.txt", "w", encoding="utf-8") as fspace:

        for plain, cipher_hex in pairs:
            print(f"\nThu: {plain}")
            print(f"Ma hoa hex: {cipher_hex}")

            p_bytes = [ord(c) for c in plain]

            try:
                c_bytes = [int(cipher_hex[i:i+2], 16) for i in range(0, len(plain)*2, 2)]
            except Exception:
                print("Loi: Dinh dang hex khong hop le")
                continue

            if len(p_bytes) != len(c_bytes):
                print(f"   Khong khop do dai: {len(p_bytes)} vs {len(c_bytes)}")
                continue

            unique_points = OrderedDict()
            conflicts = set()
            for x, y in zip(p_bytes, c_bytes):
                if x in unique_points:
                    if unique_points[x] != y:
                        conflicts.add(x)
                else:
                    unique_points[x] = y

            for x in conflicts:
                print(f"   Mau thuan: byte {x} ('{chr(x)}') anh xa toi nhieu gia tri. Bo qua.")
                del unique_points[x]

            if len(unique_points) < 2:
                print("   Khong du diem duy nhat de noi suy")
                continue

            fspace.write(f"# Thu: {plain}\n")
            for px, py in unique_points.items():
                fspace.write(f"{px:02x} {py:02x}\n")
            fspace.write("\n")

            x_vals = GF256(list(unique_points.keys()))
            y_vals = GF256(list(unique_points.values()))
            poly = galois.lagrange_poly(x_vals, y_vals)

            print("   Da thuc noi suy S(x):")
            print(f"    {poly}")

            test_enc = [int(poly(GF256(x))) for x in p_bytes]
            print("   Ket qua ma hoa thu: ", test_enc)
            print("   Ma goc:             ", c_bytes)
            print("   Khop!" if test_enc == c_bytes else "Khong khop!")

            # Giai ma: dao ham S(x)
            print("   Du doan giai ma:")
            decoded = []
            for cb in c_bytes:
                found = False
                for i in range(256):
                    if int(poly(GF256(i))) == cb:
                        decoded.append(chr(i))
                        found = True
                        break
                if not found:
                    decoded.append("?")
            decrypted_text = "".join(decoded)
            print("    Van ban giai ma:", decrypted_text)

            fout.write(decrypted_text + "\n")

            # Du doan S-box tu da thuc noi suy
            sbox_guess = [int(poly(GF256(i))) for i in range(256)]

            print("\n   Du doan S-box:")
            for i in range(0, 256, 16):
                row = " ".join(f"{b:02x}" for b in sbox_guess[i:i+16])
                print(f"   {i:03d}:", row)

            # Tinh S-box nguoc
            inverse_sbox = [0] * 256
            try:
                for i, val in enumerate(sbox_guess):
                    inverse_sbox[val] = i

                print("\n   S-box nghich dao:")
                for i in range(0, 256, 16):
                    row = " ".join(f"{b:02x}" for b in inverse_sbox[i:i+16])
                    print(f"   {i:03d}:", row)
            except IndexError:
                print("Canh bao: Gia tri khong hop le trong S-box — khong the dao nguoc (gia tri trung).")

if __name__ == "__main__":
    main()

