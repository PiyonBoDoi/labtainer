def hamming_distance(b1, b2):
    # Tinh khoang cach Hamming giua 2 byte sequence
    return sum(bin(x ^ y).count("1") for x, y in zip(b1, b2))

def main():
    file1 = input("Nhap ten file 1 (goc): ")
    file2 = input("Nhap ten file 2 (de so sanh): ")

    try:
        with open(file1, "rb") as f1, open(file2, "rb") as f2:
            data1 = f1.read()
            data2 = f2.read()
    except IOError as e:
        print("Loi mo file:", e)
        return

    min_len = min(len(data1), len(data2))
    if min_len == 0:
        print("Mot trong hai file rong hoac khong hop le.")
        return

    hd = hamming_distance(data1[:min_len], data2[:min_len])
    percent_similarity = 100.0 - (hd / (8 * min_len) * 100)

    print("Muc do tuong dong: %.2f%%" % percent_similarity)

    if percent_similarity >= 80:
        print("Ket luan: Chap nhan")
    else:
        print("Ket luan: Tuong doi")

if __name__ == "__main__":
    main()

