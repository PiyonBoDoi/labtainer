from collections import defaultdict

# Ham chuyen chuoi hex sang so nguyen
def hexstr_sang_int(h):
    return int(h, 16)

# Ham doan khoa tu file
def doan_khoa_tu_file(ten_file):
    try:
        with open(ten_file, 'r') as f:
            dong = f.readlines()
    except FileNotFoundError:
        print("Khong tim thay file.")
        return

    dem_khoa = defaultdict(int)

    for dong_du_lieu in dong:
        dong_du_lieu = dong_du_lieu.strip()
        if not dong_du_lieu or dong_du_lieu.startswith('#'):
            continue
        phan = dong_du_lieu.split()
        if len(phan) != 2:
            continue
        ro_hex, ma_hex = phan
        ro = hexstr_sang_int(ro_hex)
        ma = hexstr_sang_int(ma_hex)
        khoa_du_doan = ro ^ ma
        dem_khoa[khoa_du_doan] += 1

    # Sap xep cac khoa theo so lan xuat hien giam dan
    cac_khoa_sap_xep = sorted(dem_khoa.items(), key=lambda x: x[1], reverse=True)

    # Chuẩn bị nội dung để lưu vào file
    ket_qua = "Danh sach khoa kha nghi nhat k = ro XOR ma:\n"
    for k, so_lan in cac_khoa_sap_xep[:10]:
        dong_ket_qua = f"Khoa: 0x{k:02x}   So lan xuat hien: {so_lan}\n"
        ket_qua += dong_ket_qua

    if cac_khoa_sap_xep:
        khoa_nhieu_nhat, dem = cac_khoa_sap_xep[0]
        dong_khoa_nhieu_nhat = f"\nKhoa xuat hien nhieu nhat la: 0x{khoa_nhieu_nhat:02x} voi {dem} lan\n"
        ket_qua += dong_khoa_nhieu_nhat
    else:
        ket_qua += "Khong tim thay du lieu hop le trong file.\n"

    # Lưu kết quả vào file result.txt
    with open("result.txt", "w") as f:
        f.write(ket_qua)

    print("hoan tat, ket qua luu trong result.txt")

# Ham chinh
def main():
    ten_file = input("Nhap ten file chua du lieu ma hoa: ")
    doan_khoa_tu_file(ten_file)

if __name__ == "__main__":
    main()
