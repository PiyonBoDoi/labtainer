import random

SBOX = [0xE, 0x4, 0xD, 0x1,
        0x2, 0xF, 0xB, 0x8,
        0x3, 0xA, 0x6, 0xC,
        0x5, 0x9, 0x0, 0x7]
# Bang thay the SBOX dao nguoc
INV_SBOX = [SBOX.index(i) for i in range(16)]

PBOX = [1, 5, 2, 0, 3, 7, 6, 4]
# Hoan vi dao nguoc PBOX
INV_PBOX = [PBOX.index(i) for i in range(8)]

def permute(byte):
    # Hoan vi cac bit trong mot byte theo PBOX
    bits = [(byte >> i) & 1 for i in range(8)]
    result = 0
    for i in range(8):
        result |= bits[i] << PBOX[i]
    return result

def inverse_permute(byte):
    # Hoan vi dao nguoc cac bit trong mot byte theo INV_PBOX
    bits = [(byte >> i) & 1 for i in range(8)]
    result = 0
    for i in range(8):
        result |= bits[i] << INV_PBOX[i]
    return result

def substitute(byte):
    # Thay the nibble tren va nibble duoi bang SBOX
    hi = SBOX[(byte >> 4) & 0x0F]
    lo = SBOX[byte & 0x0F]
    return (hi << 4) | lo

def inverse_substitute(byte):
    # Thay the nibble tren va nibble duoi bang bang SBOX dao nguoc
    hi = INV_SBOX[(byte >> 4) & 0x0F]
    lo = INV_SBOX[byte & 0x0F]
    return (hi << 4) | lo

def generate_keys(master_key: int):
    # Tao 5 khoa vong tu khoa chinh master_key
    random.seed(master_key)
    return [random.randint(0, 255) for _ in range(5)]

def encrypt_byte_cbc(byte, prev_cipher, round_keys):
    # Ma hoa 1 byte theo che do CBC (Cipher Block Chaining)
    state = byte ^ prev_cipher
    for i in range(8):
        state ^= round_keys[i % 4]
        state = substitute(state)
        state = permute(state)
    return state ^ round_keys[4]

def decrypt_byte_cbc(byte, prev_cipher, round_keys):
    # Giai ma 1 byte theo che do CBC
    state = byte ^ round_keys[4]
    for i in reversed(range(8)):
        state = inverse_permute(state)
        state = inverse_substitute(state)
        state ^= round_keys[i % 4]
    return state ^ prev_cipher

def encrypt_text(data: bytes, master_key: int) -> bytes:
    # Ma hoa day byte voi khoa master_key
    keys = generate_keys(master_key)
    ciphertext = []
    prev_cipher = 0
    for b in data:
        c = encrypt_byte_cbc(b, prev_cipher, keys)
        ciphertext.append(c)
        prev_cipher = c
    return bytes(ciphertext)

def decrypt_text(cipher: bytes, master_key: int) -> bytes:
    # Giai ma day byte voi khoa master_key
    keys = generate_keys(master_key)
    plaintext = []
    prev_cipher = 0
    for c in cipher:
        p = decrypt_byte_cbc(c, prev_cipher, keys)
        plaintext.append(p)
        prev_cipher = c
    return bytes(plaintext)

def main():
    key = 0xA7

    filename = input("Nhap ten file plaintext can ma hoa: ")

    try:
        with open(filename, "rb") as f:
            plaintext = f.read()
    except IOError as e:
        print("Loi doc file:", e)
        return

    print("Plaintext:", plaintext.decode(errors='ignore'))

    ciphertext = encrypt_text(plaintext, key)
    with open("cipher.txt", "wb") as f:
        f.write(ciphertext)
    print("Encrypted bytes:", ciphertext)

    decrypted = decrypt_text(ciphertext, key)
    with open("decrypted.txt", "wb") as f:
        f.write(decrypted)
    print("Decrypted:", decrypted.decode(errors='ignore'))

if __name__ == "__main__":
    main()

