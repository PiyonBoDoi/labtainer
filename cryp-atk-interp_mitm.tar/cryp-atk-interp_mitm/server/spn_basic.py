import random

def generate_key():
    # Sinh khoa ngau nhien trong khoang 0 den 255
    key = random.randint(0, 255)
    return key

SBOX = [
    0x6, 0x4, 0xC, 0x5,
    0x0, 0x7, 0x2, 0xE,
    0x1, 0xF, 0x3, 0xD,
    0x8, 0xA, 0x9, 0xB
]

# Tinh bang SBOX dao nguoc bang cach tim vi tri cua cac gia tri 0-15 trong SBOX
INV_SBOX = [SBOX.index(i) for i in range(16)]

PBOX = [0, 2, 4, 6, 1, 3, 5, 7]

# Tinh hoan vi dao nguoc cua PBOX
INV_PBOX = [PBOX.index(i) for i in range(8)]

def permute(byte):
    # Hoan vi bit trong mot byte theo bang PBOX
    result = 0
    for i in range(8):
        bit = (byte >> i) & 1
        result |= bit << PBOX[i]
    return result

def inverse_permute(byte):
    # Hoan vi dao nguoc bit trong mot byte theo bang INV_PBOX
    result = 0
    for i in range(8):
        bit = (byte >> i) & 1
        result |= bit << INV_PBOX[i]
    return result

def substitute(byte):
    # Thay the nibble tren va nibble duoi bang bang SBOX
    hi = (byte >> 4) & 0xF
    lo = byte & 0xF
    return (SBOX[hi] << 4) | SBOX[lo]

def inverse_substitute(byte):
    # Thay the nibble tren va nibble duoi bang bang SBOX dao nguoc
    hi = (byte >> 4) & 0xF
    lo = byte & 0xF
    return (INV_SBOX[hi] << 4) | INV_SBOX[lo]

def encrypt_byte(byte, key):
    # Ma hoa mot byte voi khoa cho truong hop substitution va permutation
    state = byte ^ key
    for _ in range(3):
        state = substitute(state)
        state = permute(state)
        state ^= key
    return state

def decrypt_byte(byte, key):
    # Giai ma mot byte voi khoa theo cac vong dao nguoc
    state = byte
    for _ in range(3):
        state ^= key
        state = inverse_permute(state)
        state = inverse_substitute(state)
    state ^= key  
    return state

def encrypt_text(text, key):
    # Ma hoa mot day byte
    return bytes([encrypt_byte(b, key) for b in text])

def decrypt_text(cipher, key):
    # Giai ma mot day byte
    return bytes([decrypt_byte(b, key) for b in cipher])

def main():
    key = 0xA7
    filename = input("Nhap ten file plaintext can ma hoa: ")
    
    try:
        with open(filename, "rb") as f:
            plaintext = f.read()
    except IOError as e:
        print("Loi doc file:", e)
        return
    
    print("Plaintext:", plaintext.decode(errors='ignore'))

    ciphertext = encrypt_text(plaintext, key)
    with open("cipher.txt", "wb") as f:
        f.write(ciphertext)
    print("Encrypted bytes:", ciphertext)

    decrypted = decrypt_text(ciphertext, key)
    with open("decrypted.txt", "wb") as f:
        f.write(decrypted)
    print("Decrypted:", decrypted.decode(errors='ignore'))

if __name__ == "__main__":
    main()

